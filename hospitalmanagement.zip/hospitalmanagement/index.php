<!DOCTYPE html>
<html>
   <style>
      table {
         border:1px solid black;
         padding: 0px;
      }
      th, td{
         border:1px solid black;
         padding: 20px;
      }
   </style>
<body>
   <h2 align="center">CHOOSE YOUR OPTION</h2>
   <table style="width: 100%;">
      <tr align="center">
         <td><a href="createBill.php">Create Bill</a></td>
         <td><a href="viewBill.php">View Bill</a></td>
      </tr>
      <tr align="center">
         <td><a href="createDiagnosis.php">Create Diagnosis</a></td>
         <td><a href="viewDiagnosis.php">View Diagnosis</a></td>
      </tr>
   </table>
</body>
</html>